@echo off
setlocal EnableExtensions
cd /d "%~dp0"

rem Prefer console UTF-8 on Win10+; ignore failures on older systems.
chcp 65001 >nul 2>&1

echo ========================================
echo  Nginx Log Analyzer
echo  Dashboard: http://127.0.0.1:8099/
echo  MySQL default: localhost:3306 / nginx_log
echo  Close this window to stop the service
echo ========================================
echo.

rem ---- locate java ----
set "JAVA_CMD="
where java >nul 2>&1
if not errorlevel 1 (
  set "JAVA_CMD=java"
) else if defined JAVA_HOME if exist "%JAVA_HOME%\bin\java.exe" (
  set "JAVA_CMD=%JAVA_HOME%\bin\java.exe"
)

if not defined JAVA_CMD (
  echo [ERROR] Java not found.
  echo         Install JDK 8+ and add java.exe to PATH, or set JAVA_HOME.
  echo         未找到 Java。请安装 JDK 8+，并把 java 加入 PATH，或设置 JAVA_HOME。
  goto :fail
)

echo [INFO] Using: 
"%JAVA_CMD%" -version
echo.

rem ---- locate jar: same dir, parent dir, or nginx-log-analyzer*.jar ----
set "JAR="
if exist "%~dp0nginx-log-analyzer.jar" set "JAR=%~dp0nginx-log-analyzer.jar"
if not defined JAR if exist "%~dp0..\nginx-log-analyzer.jar" set "JAR=%~dp0..\nginx-log-analyzer.jar"
if not defined JAR (
  for %%F in ("%~dp0nginx-log-analyzer*.jar") do if exist "%%~fF" set "JAR=%%~fF"
)
if not defined JAR (
  for %%F in ("%~dp0..\nginx-log-analyzer*.jar") do if exist "%%~fF" set "JAR=%%~fF"
)

if not defined JAR (
  echo [ERROR] nginx-log-analyzer.jar not found.
  echo         Put the jar next to this start.bat, or in the parent folder.
  echo         同目录或上一级找不到 jar。当前目录: %~dp0
  goto :fail
)

echo [INFO] JAR: %JAR%
echo.

rem Open browser after a short delay (do not fail startup if this fails)
start "" cmd /c "ping -n 6 127.0.0.1 >nul & start http://127.0.0.1:8099/"

"%JAVA_CMD%" -Dfile.encoding=UTF-8 -jar "%JAR%"
set "EC=%ERRORLEVEL%"
echo.
if not "%EC%"=="0" (
  echo [ERROR] Process exited with code %EC%.
  echo         Common causes: MySQL not running / DB missing / bad password / port 8099 in use.
  echo         启动失败。常见原因：MySQL 未启动、库不存在、账号密码错误、8099 端口被占用。
  goto :fail
)

echo [INFO] Process exited normally.
pause
exit /b 0

:fail
echo.
pause
exit /b 1
